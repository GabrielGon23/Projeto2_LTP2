import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import sqlite3
import os

"""
Sistema de Estoque com Tkinter e SQLite
Aluno: Gabriel Gonçalves Sá
Matrícula: 22352853
"""

# -------------------- Banco de Dados --------------------
# Função para conectar ao banco SQLite (arquivo estoque.db)
def conectar():
    caminho_db = os.path.join(os.path.dirname(__file__), "estoque.db")  # pega o caminho do arquivo
    return sqlite3.connect(caminho_db)

# Cria as tabelas categorias e produtos, se ainda não existirem
def criar_tabelas():
    with conectar() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS categorias (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL UNIQUE
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS produtos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                quantidade INTEGER NOT NULL,
                preco REAL NOT NULL,
                categoria_id INTEGER,
                FOREIGN KEY (categoria_id) REFERENCES categorias(id)
            )
        """)

# Função para executar qualquer comando SQL, com ou sem retorno
def executar_sql(query, params=(), fetch=False):
    with conectar() as con:
        cur = con.cursor()
        cur.execute(query, params)
        return cur.fetchall() if fetch else None

# -------------------- Utilitários --------------------
# Função para validar se o valor digitado é número (int ou float) e opcionalmente maior que mínimo
def validar_numero(valor_str, tipo='int', campo='valor', minimo=None):
    valor_str_limpo = valor_str.strip()
    if valor_str_limpo.startswith('-'):
        resto = valor_str_limpo[1:]
        # Substitui vírgula por ponto para permitir float no formato brasileiro
        resto_float = resto.replace(',', '.')
        # Verifica se o resto é zero, float ou int
        if tipo == 'int':
            if resto == '0':
                messagebox.showerror("Erro", f"{campo.capitalize()} não pode ser zero negativo (-0).")
                return None
        else:  # float
            try:
                if float(resto_float) == 0:
                    messagebox.showerror("Erro", f"{campo.capitalize()} não pode ser zero negativo (-0).")
                    return None
            except ValueError:
                pass  # Vai tratar erro no bloco try-except abaixo

    try:
        valor = int(valor_str_limpo) if tipo == 'int' else float(valor_str_limpo.replace(',', '.'))
    except ValueError:
        messagebox.showerror("Erro", f"Digite um valor numérico válido para {campo}.")
        return None
    if minimo is not None and valor < minimo:
        messagebox.showerror("Erro", f"{campo.capitalize()} não pode ser menor que {minimo}.")
        return None
    return valor



# Pega o item selecionado na treeview, ou avisa se nada estiver selecionado
def selecionar_item(tree, msg_erro="Selecione um item."):
    sel = tree.selection()
    if not sel:
        messagebox.showwarning("Atenção", msg_erro)
        return None
    return sel[0]

# Atualiza o combo box de categorias com os nomes atuais do banco
def atualizar_combo_categoria():
    categorias = executar_sql("SELECT * FROM categorias ORDER BY nome", fetch=True)
    combo_categoria['values'] = [nome for _, nome in categorias]

# Limpa os campos de entrada dos produtos
def limpar_campos_produto():
    entry_nome_produto.delete(0, tk.END)
    entry_quantidade.delete(0, tk.END)
    entry_preco.delete(0, tk.END)
    combo_categoria.set('')

# -------------------- Categorias --------------------
# Lista as categorias na treeview de categorias
def listar_categorias():
    tree_categorias.delete(*tree_categorias.get_children())  # limpa a lista atual
    categorias = executar_sql("SELECT * FROM categorias ORDER BY nome", fetch=True)
    for id, nome in categorias:
        tree_categorias.insert('', tk.END, iid=str(id), values=(nome,))
    atualizar_combo_categoria()  # atualiza o combo box também

# Insere uma nova categoria no banco
def inserir_categoria():
    nome = entry_nome_categoria.get().strip()
    if not nome:
        messagebox.showwarning("Atenção", "Digite o nome da categoria.")
        return
    try:
        with conectar() as con:
            con.execute("INSERT INTO categorias (nome) VALUES (?)", (nome,))
        entry_nome_categoria.delete(0, tk.END)  # limpa o campo após inserir
        listar_categorias()
    except sqlite3.IntegrityError:
        messagebox.showerror("Erro", "Categoria já existe.")

# Edita o nome de uma categoria selecionada
def editar_categoria():
    categoria_id = selecionar_item(tree_categorias, "Selecione uma categoria para editar.")
    if not categoria_id:
        return
    nome_antigo = tree_categorias.item(categoria_id, 'values')[0]
    novo_nome = simpledialog.askstring("Editar Categoria", f"Novo nome para '{nome_antigo}':")
    if not novo_nome:
        return
    try:
        with conectar() as con:
            con.execute("UPDATE categorias SET nome = ? WHERE id = ?", (novo_nome.strip(), categoria_id))
        listar_categorias()
    except sqlite3.IntegrityError:
        messagebox.showerror("Erro", "Nome de categoria duplicado.")

# Exclui a categoria selecionada, se confirmada pelo usuário
def excluir_categoria():
    categoria_id = selecionar_item(tree_categorias, "Selecione uma categoria para excluir.")
    if not categoria_id:
        return
    if messagebox.askyesno("Confirmação", "Deseja excluir esta categoria?"):
        try:
            with conectar() as con:
                con.execute("DELETE FROM categorias WHERE id = ?", (categoria_id,))
            listar_categorias()
            listar_produtos()  # atualiza produtos pois categoria pode ter produtos
        except sqlite3.IntegrityError:
            messagebox.showerror("Erro", "Não é possível excluir uma categoria com produtos vinculados.")

# Lista os produtos da categoria selecionada, mudando para a aba Produtos
def listar_produtos_da_categoria_selecionada():
    categoria_id = selecionar_item(tree_categorias, "Selecione uma categoria para listar seus produtos.")
    if not categoria_id:
        return
    listar_produtos(filtrar_categoria_id=int(categoria_id))
    notebook.select(aba_produtos)

# -------------------- Produtos --------------------
# Lista os produtos, opcionalmente filtrando por categoria
def listar_produtos(filtrar_categoria_id=None):
    tree_produtos.delete(*tree_produtos.get_children())
    if filtrar_categoria_id:
        produtos = executar_sql("""
            SELECT p.id, p.nome, p.quantidade, p.preco, c.nome
            FROM produtos p
            JOIN categorias c ON p.categoria_id = c.id
            WHERE c.id = ?
            ORDER BY p.nome
        """, (filtrar_categoria_id,), fetch=True)
    else:
        produtos = executar_sql("""
            SELECT p.id, p.nome, p.quantidade, p.preco, c.nome
            FROM produtos p
            LEFT JOIN categorias c ON p.categoria_id = c.id
            ORDER BY p.nome
        """, fetch=True)
    for id, nome, qtd, preco, cat_nome in produtos:
        tree_produtos.insert('', tk.END, iid=str(id), values=(nome, qtd, preco, cat_nome))

# Salva um produto no banco (novo ou editado)
def salvar_produto(id_produto=None, nome=None, qtd_str=None, preco_str=None, categoria_str=None, janela=None):
    if not all([nome, qtd_str, preco_str, categoria_str]):
        messagebox.showwarning("Atenção", "Preencha todos os campos.")
        return False

    qtd = validar_numero(qtd_str, 'int', 'quantidade', 0)
    preco = validar_numero(preco_str, 'float', 'preço', 0)
    if qtd is None or preco is None:
        return False

    categoria_id = executar_sql("SELECT id FROM categorias WHERE nome = ?", (categoria_str,), fetch=True)
    if not categoria_id:
        messagebox.showerror("Erro", "Categoria não encontrada.")
        return False
    categoria_id = categoria_id[0][0]

    try:
        with conectar() as con:
            if id_produto:
                con.execute("""
                    UPDATE produtos SET nome = ?, quantidade = ?, preco = ?, categoria_id = ? WHERE id = ?
                """, (nome.strip(), qtd, preco, categoria_id, id_produto))
            else:
                con.execute("""
                    INSERT INTO produtos (nome, quantidade, preco, categoria_id) VALUES (?, ?, ?, ?)
                """, (nome.strip(), qtd, preco, categoria_id))
        listar_produtos()  # atualiza a lista de produtos
        if not id_produto:
            limpar_campos_produto()
        if janela:
            janela.destroy()
        return True
    except Exception as e:
        messagebox.showerror("Erro", f"Erro ao salvar produto: {e}")
        return False

# Função para inserir produto chamando salvar_produto com dados da interface
def inserir_produto():
    salvar_produto(
        nome=entry_nome_produto.get().strip(),
        qtd_str=entry_quantidade.get().strip(),
        preco_str=entry_preco.get().strip(),
        categoria_str=combo_categoria.get()
    )

# Edita produto selecionado mostrando uma janela com os dados atuais
def editar_produto():
    id_produto = selecionar_item(tree_produtos, "Selecione um produto para editar.")
    if not id_produto:
        return

    item = tree_produtos.item(id_produto)
    nome_atual, qtd_atual, preco_atual, cat_atual = item['values']

    edit_win = tk.Toplevel(root)
    edit_win.title("Editar Produto")
    edit_win.geometry("300x300")

    campos = {}
    for label, valor in [("Nome:", nome_atual), ("Quantidade:", str(qtd_atual)), ("Preço:", str(preco_atual))]:
        tk.Label(edit_win, text=label).pack()
        entry = ttk.Entry(edit_win)
        entry.pack()
        entry.insert(0, valor)
        campos[label] = entry

    tk.Label(edit_win, text="Categoria:").pack()
    categoria_combo = ttk.Combobox(edit_win, width=28)
    categorias = executar_sql("SELECT nome FROM categorias ORDER BY nome", fetch=True)
    valores_cat = [nome for nome, in categorias]
    categoria_combo['values'] = valores_cat
    categoria_combo.pack()
    categoria_combo.set(cat_atual)

    ttk.Button(edit_win, text="Salvar", command=lambda: salvar_produto(
        id_produto=id_produto,
        nome=campos["Nome:"].get().strip(),
        qtd_str=campos["Quantidade:"].get().strip(),
        preco_str=campos["Preço:"].get().strip(),
        categoria_str=categoria_combo.get(),
        janela=edit_win
    )).pack(pady=10)

# Exclui produto selecionado após confirmação
def excluir_produto():
    produto_id = selecionar_item(tree_produtos, "Selecione um produto para excluir.")
    if not produto_id:
        return
    if messagebox.askyesno("Confirmação", "Deseja excluir este produto?"):
        with conectar() as con:
            con.execute("DELETE FROM produtos WHERE id = ?", (produto_id,))
        listar_produtos()

# -------------------- Interface Gráfica --------------------
root = tk.Tk()
root.title("Sistema de Estoque")
root.geometry("800x600")

notebook = ttk.Notebook(root)
notebook.pack(fill='both', expand=True)

# Aba Categorias (para gerenciar categorias)
aba_categorias = ttk.Frame(notebook)
notebook.add(aba_categorias, text='Categorias')

ttk.Label(aba_categorias, text="Nome da Categoria:").pack(pady=2)
entry_nome_categoria = ttk.Entry(aba_categorias, width=30)
entry_nome_categoria.pack(pady=2)

ttk.Button(aba_categorias, text="Inserir Categoria", command=inserir_categoria).pack(pady=2)
ttk.Button(aba_categorias, text="Editar Categoria", command=editar_categoria).pack(pady=2)
ttk.Button(aba_categorias, text="Excluir Categoria", command=excluir_categoria).pack(pady=2)
ttk.Button(aba_categorias, text="Listar Produtos da Categoria Selecionada", command=listar_produtos_da_categoria_selecionada).pack(pady=8)

tree_categorias = ttk.Treeview(aba_categorias, columns=('Nome',), show='headings', height=10)
tree_categorias.heading('Nome', text='Nome')
tree_categorias.pack(fill='both', expand=True, pady=5)

# Aba Produtos (para gerenciar produtos)
aba_produtos = ttk.Frame(notebook)
notebook.add(aba_produtos, text='Produtos')

ttk.Label(aba_produtos, text="Nome do Produto:").pack(pady=2)
entry_nome_produto = ttk.Entry(aba_produtos, width=30)
entry_nome_produto.pack(pady=2)

ttk.Label(aba_produtos, text="Quantidade:").pack(pady=2)
entry_quantidade = ttk.Entry(aba_produtos, width=30)
entry_quantidade.pack(pady=2)

ttk.Label(aba_produtos, text="Preço:").pack(pady=2)
entry_preco = ttk.Entry(aba_produtos, width=30)
entry_preco.pack(pady=2)

ttk.Label(aba_produtos, text="Categoria:").pack(pady=2)
combo_categoria = ttk.Combobox(aba_produtos, width=28)
combo_categoria.pack(pady=2)

ttk.Button(aba_produtos, text="Inserir Produto", command=inserir_produto).pack(pady=2)
ttk.Button(aba_produtos, text="Editar Produto", command=editar_produto).pack(pady=2)
ttk.Button(aba_produtos, text="Excluir Produto", command=excluir_produto).pack(pady=2)

cols_produtos = ('Nome', 'Quantidade', 'Preço', 'Categoria')
tree_produtos = ttk.Treeview(aba_produtos, columns=cols_produtos, show='headings', height=15)
for col in cols_produtos:
    tree_produtos.heading(col, text=col)
tree_produtos.pack(fill='both', expand=True, pady=10)

# Inicializa o banco e as listas da interface
criar_tabelas()
listar_categorias()
listar_produtos()

root.mainloop()
